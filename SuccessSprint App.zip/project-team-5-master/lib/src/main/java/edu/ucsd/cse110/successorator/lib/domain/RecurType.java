package edu.ucsd.cse110.successorator.lib.domain;

public enum RecurType {
    PENDING, ONCE, DAILY, WEEKLY, MONTHLY, YEARLY
}
