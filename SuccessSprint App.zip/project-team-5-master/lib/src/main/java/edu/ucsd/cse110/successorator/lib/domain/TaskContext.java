package edu.ucsd.cse110.successorator.lib.domain;

public enum TaskContext {
    HOME, WORK, SCHOOL, ERRAND;
}
