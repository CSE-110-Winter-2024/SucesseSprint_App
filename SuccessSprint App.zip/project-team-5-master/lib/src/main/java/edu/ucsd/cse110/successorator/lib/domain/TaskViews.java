package edu.ucsd.cse110.successorator.lib.domain;

public enum TaskViews {

    TODAY_VIEW,
    TOMORROW_VIEW,
    PENDING_VIEW,
    RECURRING_VIEW,
    HOME_VIEW,
    WORK_VIEW,
    SCHOOL_VIEW,
    ERRAND_VIEW;

}
