package edu.ucsd.cse110.successorator.lib.domain;

public enum ContextViews {
    ALL,
    HOME,
    WORK,
    SCHOOL,
    ERRAND;
}
